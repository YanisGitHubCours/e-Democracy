import 'package:flutter/material.dart';

const Color peach = Color(0xFFF09676);
const Color pitaya = Color(0xFFEB466C);
const Color bgColor = Color(0xFFEEEEEE);
const Color grey = Color(0xFF474747);
Color dark = const Color(0xFF363740);

const defaultPadding = 20.0;
